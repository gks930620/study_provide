package question;


import java.util.Scanner;

public class Question1 {
	public static void main(String[] args) {
	}
}
