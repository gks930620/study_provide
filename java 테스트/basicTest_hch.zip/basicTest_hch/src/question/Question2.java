package question;


import java.util.Scanner;

public class Question2 {
	public static void main(String[] args) {
		
	}
}
