package question;


public class Question2 {
	public static void main(String[] args) {
		
		
	}
}
