package question;
public class Question5 {
	public static void main(String[] args) {
		
	}
}
