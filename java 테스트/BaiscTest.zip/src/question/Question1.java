package question;


public class Question1 {
	public static void main(String[] args) {
		
	}
}
