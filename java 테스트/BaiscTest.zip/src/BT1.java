
public class BT1 {
	//메소드 선언부(리턴타입,메소드 이름, 매개변수 선언)는 건들지 마세요. 에러가 나지 않도록 메소드 실행부를 고쳐보세요.  값은 어떤 값이든 상관없습니다.
	static int doYouKnowMethod1() {

	}
	
	//메소드 선언부(리턴타입,메소드 이름, 매개변수 선언)는 건들지 마세요. 에러가 나지 않도록 메소드 실행부를 고쳐보세요. 
	static void doYouKnowMethod2() {
		
		return "return";
	}
	
	 
	public static void main(String[] args) {
		String a= doYouKnowMethod1();   //에러가 나지 않도록 수정하세요.   doYouKnowMethod1 메소드는 건들지 않습니다.
	} 
	
	
}
