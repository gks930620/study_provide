
public class BT2 {
	
	//메인 메소드는 건들지 않습니다.  메인메소드 출력결과가 14가 되도록 sum 메소드를 수정하세요
	public static void main(String[] args) {
		int sum= sum(3,5,6);
		System.out.println(sum);   
	}
	
	
	static int sum(int a, int b) {
		
	}
	
}
